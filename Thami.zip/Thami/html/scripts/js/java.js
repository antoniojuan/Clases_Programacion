function sumardel1al10() {
    var total=0;
  for(i=1;i<=10;i++){
    total=total+i
  }  
  alert(total);
}

function sumarhasta(numero) {
    var total=0;
  for(i=1;i<=numero;i++){
    total=total+i
  }  
  alert(total);
}
